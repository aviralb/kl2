from flask import Flask, request
from flask_restful import Resource, Api
import CalculatorAtFlask.handler as Cal
from flask import jsonify

app = Flask(__name__)
api = Api(app)


@app.route('/')
def page1():
    return 'Hello Aviral Bhardwaj This is Calculator App in Webservices'


@app.route('/add', methods=['POST'])
def addition():
    file = request.get_json()
    one = file['Number1']
    two = file['Number2']
    result = Cal.Calculator.add(one, two)
    res = ({"Addition": result})
    return jsonify(res)


@app.route('/sub', methods=['POST'])
def sub():
    file = request.get_json()
    one = file['Number1']
    two = file['Number2']
    result = Cal.Calculator.subtract(one, two)
    res = ({"Subtraction": result})
    return jsonify(res)


@app.route('/multi', methods=['POST'])
def multi():
    file = request.get_json()
    one = file['Number1']
    two = file['Number2']
    result = Cal.Calculator.multiply(one, two)
    res = ({"Division": result})
    return jsonify(res)


def divi():
    file = request.get_json()
    one = file['Number1']
    two = file['Number2']
    result = Cal.Calculator.divide(one, two)
    res = ({"Division": result})
    return jsonify(res)


if __name__ == '__main__':
    app.run(debug=True)
