class Calculator:
    def add(x, y):
        return int(x) + int(y)

    # This function subtracts two numbers
    def subtract(x, y):
        return int(x) - int(y)

    # This function multiplies two numbers
    def multiply(x, y):
        return int(x) * int(y)

    # This function divides two numbers
    def divide(x, y):
        return int(x) / int(y)
