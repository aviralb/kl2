import pysftp
import paramiko
import boto3
import docker
from scripts.core import sample

def ec2_inst_conn(private_key_file_loc,instance_ip,uname,command_list):
    """

    :param private_key_file_loc:
    :param instance_ip:
    :param uname:
    :param command_list:
    :return:
    """
    key = paramiko.RSAKey.from_private_key_file(private_key_file_loc)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    # Connect to ec2 instance
    try:
        # Ec2 Instance Credentials
        client.connect(hostname=instance_ip, username=uname, pkey=key)
        try:
            # Execute list of commands
            for cmd in command_list:
                stdin, stdout, stderr = client.exec_command(cmd)
                print(stdout.read())
        except Exception as e:
            print(e)

        # close the client connection
        client.close()

    except Exception as e:
        print(e)



def upload_image_ecr(AWS_ACCESS_KEY_ID,AWS_SECRET_ACCESS_KEY,AWS_DEFAULT_REGION,regId,repoName,imageName,imageTag):
    """

    :param AWS_ACCESS_KEY_ID:
    :param AWS_SECRET_ACCESS_KEY:
    :param AWS_DEFAULT_REGION:
    :param regId:
    :param repoName:
    :param imageName:
    :param imageTag:
    :return:
    """
    client = boto3.client('ecr',
                          aws_access_key_id=AWS_ACCESS_KEY_ID,
                          aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
                          region_name=AWS_DEFAULT_REGION
                          )
    response = client.put_image(
        registryId=regId,
        repositoryName=repoName,
        imageManifest=imageName,
        imageTag=imageTag
    )

    return response


def update_image_ecs(access_key_id,secret_access_key,aws_region,ECS_CLUSTER,ECS_SERVICE):
    """

    :param access_key_id:
    :param secret_access_key:
    :param aws_region:
    :param ECS_CLUSTER:
    :param ECS_SERVICE:
    :return:
    """

    # force new deployment of ECS service
    ecs_client = boto3.client(
        'ecs', aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key, region_name=aws_region)

    response = ecs_client.update_service(
        cluster=ECS_CLUSTER, service=ECS_SERVICE, forceNewDeployment=True)

    return response


def run_image_service(access_key_id,secret_access_key,aws_region):
    """

    :param access_key_id:
    :param secret_access_key:
    :param aws_region:
    :return:
    """
    # ecs client connection
    ecs_client = boto3.client(
        'ecs', aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key, region_name=aws_region)



    #details
    cluster_name=sample.cluster
    taskDef=sample.taskDefinition
    override_rule=sample.overrides
    total_count=sample.count
    startBy=sample.startedBy
    groupInfo=sample.group
    placement_cons=sample.placementConstraints
    place_strategy=sample.placementStrategy
    launch_type=sample.launchType
    platform_version=sample.platformVersion
    network_config=sample.networkConfiguration
    tag_name=sample.tags
    enable_ecs_managedTags=sample.enableECSManagedTags
    propagate_tags=sample.propagateTags




    response = ecs_client.run_task(
        cluster=cluster_name,
        taskDefinition=taskDef,
        overrides=override_rule,
        count=total_count,
        startedBy=startBy,
        group=groupInfo,
        placementConstraints=placement_cons,
        placementStrategy=place_strategy,
        launchType=launch_type,
        platformVersion=platform_version,
        networkConfiguration=network_config,
        tags=tag_name,
        enableECSManagedTags=enable_ecs_managedTags,
        propagateTags=propagate_tags
    )


    return response


def delete_ecs_service(access_key_id,secret_access_key,aws_region,cluster_name,service_name):
    """

    :param access_key_id:
    :param secret_access_key:
    :param aws_region:
    :param cluster_name:
    :param service_name:
    :return:
    """
    # ecs client connection
    ecs_client = boto3.client(
        'ecs', aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key, region_name=aws_region)

    response = ecs_client.delete_service(
        cluster=cluster_name,
        service=service_name,
        force=True
    )

    return response



def ecs_start_service(access_key_id,secret_access_key,aws_region):
    """

    :param access_key_id:
    :param secret_access_key:
    :param aws_region:
    :return:
    """

    cluster_name = sample.cluster
    taskDef = sample.taskDefinition
    override_rule = sample.overrides
    total_count = sample.count
    startBy = sample.startedBy
    groupInfo = sample.group

    network_config = sample.networkConfiguration
    tag_name = sample.tags
    enable_ecs_managedTags = sample.enableECSManagedTags
    propagate_tags = sample.propagateTags
    container_instances=sample.containerInstances

    # ecs client connection
    ecs_client = boto3.client(
        'ecs', aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key, region_name=aws_region)
    response = ecs_client.start_task(
        cluster=cluster_name,
        taskDefinition=taskDef,
        overrides=override_rule,
        startedBy=startBy,
        group=groupInfo,
        containerInstances=container_instances,
        networkConfiguration=network_config,
        tags=tag_name,
        enableECSManagedTags=enable_ecs_managedTags,
        propagateTags=propagate_tags
    )





def ecs_stop_service(access_key_id,secret_access_key,aws_region):
    # ecs client connection
    ecs_client = boto3.client(
        'ecs', aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key, region_name=aws_region)

    response = ecs_client.stop_task(
        cluster=sample.cluster,
        task=sample.task,
        reason=sample.reason
    )
