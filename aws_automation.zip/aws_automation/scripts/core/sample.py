cluster='string',
taskDefinition='string',
overrides={
    'containerOverrides': [
        {
            'name': 'string',
            'command': [
                'string',
            ],
            'environment': [
                {
                    'name': 'string',
                    'value': 'string'
                },
            ],
            'cpu': 123,
            'memory': 123,
            'memoryReservation': 123,
            'resourceRequirements': [
                {
                    'value': 'string',
                    'type': 'GPU'|'InferenceAccelerator'
                },
            ]
        },
    ],
    'inferenceAcceleratorOverrides': [
        {
            'deviceName': 'string',
            'deviceType': 'string'
        },
    ],
    'taskRoleArn': 'string',
    'executionRoleArn': 'string'
},
count=123,
startedBy='string',
group='string',
placementConstraints=[
    {
        'type': 'distinctInstance'|'memberOf',
        'expression': 'string'
    },
],
placementStrategy=[
    {
        'type': 'random'|'spread'|'binpack',
        'field': 'string'
    },
],
launchType='EC2'|'FARGATE',
platformVersion='string',
networkConfiguration={
    'awsvpcConfiguration': {
        'subnets': [
            'string',
        ],
        'securityGroups': [
            'string',
        ],
        'assignPublicIp': 'ENABLED'|'DISABLED'
    }
},
tags=[
    {
        'key': 'string',
        'value': 'string'
    },
],
enableECSManagedTags=True|False,
propagateTags='TASK_DEFINITION'|'SERVICE'

containerInstances=[
            'string',
        ]

task="task name"
reason="reason to stop"